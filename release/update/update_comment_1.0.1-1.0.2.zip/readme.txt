Comment update 1.0.2

System requirements: 
Module depends:

