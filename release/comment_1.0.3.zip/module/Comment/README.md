# Comment
Comment module for Dream CMS. Module allows to publish comments on the site.
