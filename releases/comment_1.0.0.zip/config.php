<?php 

return [
	'module_path' => 'module/Comment',
    'layout_path' => 'layout/comment'
];
